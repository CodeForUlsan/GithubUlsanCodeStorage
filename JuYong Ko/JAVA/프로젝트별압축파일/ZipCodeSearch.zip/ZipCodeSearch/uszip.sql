/*
�������� �α�
!!!�����Ŀ��� �ݵ�� �α׸� �������ֽʽÿ�!!!
�α� ��Ģ - �տ��� ������ ���ڰ� ���ϴ�. ���ڵڿ� �ٴ� Revision�� �ش��� ù��° �ǿø��� ��� ���� 1�� �ι�°�� ��쿣 ���� 2�� �ٿ��ֽø� �˴ϴ�.
ex)2018�� 12�� 21�� ù��° ������ - 2018.12.21.Revision1, 2018�� 12�� 21�� �ι�° ������ - 2018.12.21.Revision2
2018.12.21.Revision1
*/

--������ ���̺�
create table Gangwon(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--��⵵ ���̺�
create table Gyeonggi(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--��󳲵� ���̺�
create table Gyeongsangnam(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--���ϵ� ���̺�
create table Gyeongsangbuk(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--���ֱ����� ���̺�
create table Gwangju(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--�뱸������ ���̺�
create table Daegu(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--���������� ���̺�
create table Daejeon(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--�λ걤���� ���̺�
create table Busan(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--����Ư���� ���̺�
create table Seoul(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--����Ư����ġ�� ���̺�
create table Sejong(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--��걤���� ���̺�
create table Ulsan(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--��õ������ ���̺�
create table Incheon(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--���󳲵� ���̺�
create table Jeollanam(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--����ϵ� ���̺�
create table Jeollabuk(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--����Ư����ġ�� ���̺�
create table Jeju(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--��û���� ���̺�
create table Chungcheongnam(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);
--��û�ϵ� ���̺�
create table Chungcheongbuk(
	zipcode varchar(30),
	city varchar(50),
	cityEng varchar(50),
	country varchar(50),
	countryEng varchar(50),
	town varchar(50),
	townEng varchar(50),
	roadName varchar(50),
	roadNameEng varchar(50),
	buildNumberMain varchar(10),
	buildNumbersub varchar(10),
	deliveryName varchar(50),
	buildName varchar(50),
	villageName varchar(50),
	subTown varchar(50),
	lotNumberMain varchar(10),
	lotNumberSub varchar(10)
);

--���̺� ��ü ����
select * from sqlite_master;

--���̺� ����
--drop table Gangwon;
--drop table Gyeonggi;
--drop table Gyeongsangnam;
--drop table Gyeongsangbuk;
--drop table Gwangju;
--drop table Daegu;
--drop table Daejeon;
--drop table Busan;
--drop table Seoul;
--drop table Sejong;
--drop table Ulsan;
--drop table Incheon;
--drop table Jeollanam;
--drop table Jeollabuk;
--drop table Jeju;
--drop table Chungcheongnam;
--drop table Chungcheongbuk;

--���̺� ��ü ��ȸ
select * from Gangwon;
select * from Gyeonggi;
select * from Gyeongsangnam;
select * from Gyeongsangbuk;
select * from Gwangju;
select * from Daegu;
select * from Daejeon;
select * from Busan;
select * from Seoul;
select * from Sejong;
select * from Ulsan;
select * from Incheon;
select * from Jeollanam;
select * from Jeollabuk;
select * from Jeju;
select * from Chungcheongnam;
select * from Chungcheongbuk;

--�� ���̺��� ���ڵ� ��ü ����
--delete from Gangwon;
--delete from Gyeonggi;
--delete from Gyeongsangnam;
--delete from Gyeongsangbuk;
--delete from Gwangju;
--delete from Daegu;
--delete from Daejeon;
--delete from Busan;
--delete from Seoul;
--delete from Sejong;
--delete from Ulsan;
--delete from Incheon;
--delete from Jeollanam;
--delete from Jeollabuk;
--delete from Jeju;
--delete from Chungcheongnam;
--delete from Chungcheongbuk;


--�˻� ���ǹ���
select * from uszip where city = '��걤����' and country = '����' and villageName = '�޵�';

select * from uszip where city like '���%';

select count(*) from gangwon;

select * from Ulsan where country = '����' and villageName like '%�޵�%';

select distinct(country) from Daegu;

select distinct(villagename) from Ulsan;

select * from Ulsan where country = '����' and villageName = '�޵�';


select * from (select * from Ulsan where country = '����' and villageName = '�޵�')
where buildName like '%130%' or lotNumberMain like '%130%' or lotNumberSub like '%130%';

select count(*) from Ulsan where country = '����' and villageName like '%�޵�%';

select count(*) from (select * from Ulsan where country = '����' and villageName = '�޵�')
where buildName like '%130%' or lotNumberMain like '%130%' or lotNumberSub like '%130%';

select * from (select * from Ulsan where country = '����' and roadName = 'ȭ�շ�')
where buildName = '%12%' or buildNumberMain like '%12%' or buildNumberSub like '%12%'; 

select count(*) from (select * from Ulsan where country = '����' and villageName = '�޵�')
where buildName like '%%' or lotNumberMain like '%%' or lotNumberSub like '%%';

select * from gangwon where country = '���ֽ�' and villageName = '���嵿' and lotNumberMain = '801' and lotNumberSub = '44';

select count(*) from ulsan;
select * from ulsan where rowid = (select count(*) from ulsan);
select * from ulsan where rowid = 98566;

select * from ulsan where roadName like '%���%';