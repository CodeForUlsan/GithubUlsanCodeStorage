#ifndef _COPYRIGHTWNDPROCS_H_
#define _COPYRIGHTWNDPORCS_H_
LRESULT CALLBACK CopyrightWndProc(HWND hCopyrightWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK CloseCopyrightImageButtonWndProc(HWND hCloseCopyrightImageButtonWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK MakerLogoImageWndProc(HWND hMakerLogoImageWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ProgramLogoImageWndProc(HWND hProgramLogoImageWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
#endif