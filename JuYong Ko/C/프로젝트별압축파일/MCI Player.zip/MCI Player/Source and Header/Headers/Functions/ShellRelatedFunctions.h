#ifndef _SHELLRELATEDFUNCTIONS_H_
#define _SHELLRELATEDFUNCTIONS_H_
void NotifyIconDataCall(HWND hWnd, NOTIFYICONDATA *NotifyIconData, int Tray);
#endif