#ifndef _MENURELATEDFUNCTIONS_H_
#define _MENURELATEDFUNCTIONS_H_
void FloatingPopupMenuCall(HWND hWnd, HMENU hMenu, HMENU hPopup, POINT Point);
#endif