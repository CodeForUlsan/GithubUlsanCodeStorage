#ifndef _TEMPORARYFUNCTIONS_H_
#define _TEMPORARYFUNCTIONS_H_
HWND CreateChildButton(TCHAR *WindowCaption, RECT *WinClientRectangle, 
					   int ButtonPositionX, int ButtonPositionY, int ButtonWidth, int ButtonHeight, 
					   HWND *hWnd, HMENU ButtonWindowID);
#endif