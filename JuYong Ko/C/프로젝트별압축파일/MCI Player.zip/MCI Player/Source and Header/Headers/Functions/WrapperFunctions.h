#ifndef _WRAPPERFUNCTIONS_H_
#define _WRAPPERFUNCTIONS_H_
void WrapperMusicFilePlayFunction(HWND hWnd, TCHAR *Global_lpstrFile, DWORD *MciErrorResult);
#endif