#ifndef _MCIPLAYRELATEDFUNCTIONS_H_
#define _MCIPLAYRELATEDFUNCTIONS_H_
void PlayTimePrintStatic(LPWSTR MciPlayTimeString);
void StateChangeToPlayOrPause(BOOL *PlayorPause);
#endif