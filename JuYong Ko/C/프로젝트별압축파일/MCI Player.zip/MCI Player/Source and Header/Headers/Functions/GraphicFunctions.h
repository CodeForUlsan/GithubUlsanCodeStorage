#ifndef _GRAPHICFUNCTIONS_H_
#define _GRAPHICFUNCTIONS_H_
void CustomButtonImageDoubleBuffering(HDC MainDC, LPCTSTR BitmapFileName);
void WndLayerTransparentOnOff(BOOL GlassOnOff, HWND hWnd);
#endif