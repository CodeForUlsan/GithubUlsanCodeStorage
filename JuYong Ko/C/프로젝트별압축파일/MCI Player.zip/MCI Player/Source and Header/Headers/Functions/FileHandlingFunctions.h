#ifndef _FILEHANDLINGFUNCTIONS_H_
#define _FILEHANDLINGFUNCTIONS_H_
void OpenFileNameDialogCall(HWND hWnd, OPENFILENAME *OpenFileName, TCHAR *lpstrFile, TCHAR *lpstrFileTitle);
#endif