package com.zcs.proc;

public class ZipCodeBean {

	// 1. ������ȣ - zipcode
	private String zipcode;
	// 2. �õ� - city
	private String city;
	// 3. �õ����� - cityEng
	private String cityEng;
	// 4. �ñ��� - country
	private String country;
	// 5. �ñ������� - countryEng
	private String countryEng;
	// 6. ���� - town
	private String town;
	// 7. ���鿵�� - townEng
	private String townEng;
	// 8. ���θ� - roadName
	private String roadName;
	// 9. ���θ����� - roadNameEng
	private String roadNameEng;
	// 10. �ǹ���ȣ���� - buildNumberMain
	private String buildNumberMain;
	// 11. �ǹ���ȣ�ι� - buildNumberSub
	private String buildNumberSub;	
	// 12. �뷮���ó�� - deliveryName
	private String deliveryName;
	// 13. �ñ�����ǹ��� - buildName
	private String buildName;
	// 14. �������� - villageName
	private String villageName;
	// 15. �� - subTown
	private String subTown;
	// 16. �������� - lotNumberMain
	private String lotNumberMain;
	// 17. �����ι� - lotNumberSub
	private String lotNumberSub;

	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCityEng() {
		return cityEng;
	}
	public void setCityEng(String cityEng) {
		this.cityEng = cityEng;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryEng() {
		return countryEng;
	}
	public void setCountryEng(String countryEng) {
		this.countryEng = countryEng;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getTownEng() {
		return townEng;
	}
	public void setTownEng(String townEng) {
		this.townEng = townEng;
	}
	public String getRoadName() {
		return roadName;
	}
	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}
	public String getRoadNameEng() {
		return roadNameEng;
	}
	public void setRoadNameEng(String roadNameEng) {
		this.roadNameEng = roadNameEng;
	}
	public String getBuildNumberMain() {
		return buildNumberMain;
	}
	public void setBuildNumberMain(String buildNumberMain) {
		this.buildNumberMain = buildNumberMain;
	}
	public String getBuildNumberSub() {
		return buildNumberSub;
	}
	public void setBuildNumberSub(String buildNumberSub) {
		this.buildNumberSub = buildNumberSub;
	}
	public String getDeliveryName() {
		return deliveryName;
	}
	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}
	public String getBuildName() {
		return buildName;
	}
	public void setBuildName(String buildName) {
		this.buildName = buildName;
	}
	public String getVillageName() {
		return villageName;
	}
	public void setVillageName(String villageName) {
		this.villageName = villageName;
	}
	public String getSubTown() {
		return subTown;
	}
	public void setSubTown(String subTown) {
		this.subTown = subTown;
	}
	public String getLotNumberMain() {
		return lotNumberMain;
	}
	public void setLotNumberMain(String lotNumberMain) {
		this.lotNumberMain = lotNumberMain;
	}
	public String getLotNumberSub() {
		return lotNumberSub;
	}
	public void setLotNumberSub(String lotNumberSub) {
		this.lotNumberSub = lotNumberSub;
	}
}